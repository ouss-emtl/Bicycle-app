package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CommandLineTest {

	@Test
	void testCommandline() {
		fail("Not yet implemented");
	}

}
